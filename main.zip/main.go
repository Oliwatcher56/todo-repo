package main

import (
	"fmt"
	"io"
	"net/http"
	"strconv"
	"sync"
)

var mtx = sync.Mutex{}
var money = 1000
var bank = 0

func payHandler(w http.ResponseWriter, r *http.Request) {
	// for k, v := range r.Header {
	// 	fmt.Println("k:", k, "v:", v)
	// } - перебор хедеров

	// r.Method - метод

	httpRequestBody, err := io.ReadAll(r.Body)
	if err != nil {
		w.WriteHeader(http.StatusInternalServerError)

		msg := "HTTP BODY ERROR:" + err.Error()

		fmt.Println(msg)

		_, err = w.Write([]byte(msg))

		if err != nil {
			fmt.Println("FAIL TO WRITE HTTP RESPONSE")

		}
		return
	}

	httpRequestBodyString := string(httpRequestBody)

	paymentAmount, err := strconv.Atoi(httpRequestBodyString)

	if err != nil {
		w.WriteHeader(http.StatusBadRequest)

		msg := "FAILED TO CONVERT BODY:" + err.Error()

		fmt.Println(msg)

		_, err = w.Write([]byte(msg))

		if err != nil {
			fmt.Println("FAIL TO WRITE HTTP RESPONSE", err)
		}

		return
	}

	mtx.Lock()
	if money >= paymentAmount {
		msg := "PAYMENT ACCEPTED | " + strconv.Itoa(money)
		money -= paymentAmount

		_, err = w.Write([]byte(msg))

		if err != nil {
			fmt.Println("FAIL TO WRITE HTTP RESPONSE", err)
		}

		fmt.Println(msg)
	} else {
		msg := "PAYMENT DECLINED"

		_, err = w.Write([]byte(msg))

		if err != nil {
			fmt.Println("FAIL TO WRITE HTTP RESPONSE", err)
		}

		fmt.Println(msg)
	}
	mtx.Unlock()
}

func saveHandler(w http.ResponseWriter, r *http.Request) {
	httpRequestBody, err := io.ReadAll(r.Body)

	if err != nil {
		msg := "FAILED TO READ HTTP BODY" + err.Error()

		_, err = w.Write([]byte(msg))

		fmt.Println(msg)

		if err != nil {
			fmt.Println("FAIL TO WRITE HTTP RESPONSE", err)

		}
		return
	}

	httpRequestBodyString := string(httpRequestBody)

	saveAmount, err := strconv.Atoi(httpRequestBodyString)

	if err != nil {
		msg := "FAILED TO CONVERT BODY:" + err.Error()

		_, err = w.Write([]byte(msg))

		fmt.Println(msg)

		if err != nil {
			fmt.Println("FAIL TO WRITE HTTP RESPONSE", err)
		}
		return
	}
	mtx.Lock()
	if money >= saveAmount {

		msg := "TRANSFER WAS SUCCESFUL |" + strconv.Itoa(money)
		balanceMsg := "YOUR CURRENT BANK IS :" + strconv.Itoa(money)

		money -= saveAmount
		bank += saveAmount

		fmt.Println(msg)

		_, err = w.Write([]byte(msg))

		if err != nil {
			fmt.Println("FAIL TO WRITE HTTP RESPONSE")
		}

		fmt.Println(balanceMsg)

		_, err = w.Write([]byte(balanceMsg))

		if err != nil {
			fmt.Println("FAIL TO WRITE HTTP RESPONSE WITH BALANCE")
		}
	} else {
		msg := "TRANSFER WAS DECLINED"
		_, err = w.Write([]byte(msg))
		fmt.Println(msg)
		if err != nil {
			fmt.Println(fmt.Println("FAIL TO WRITE HTTP RESPONSE"))
		}
	}
	mtx.Unlock()
}

func main() {

	http.HandleFunc("/pay", payHandler)
	http.HandleFunc("/save", saveHandler)

	err := http.ListenAndServe(":9091", nil)
	if err != nil {
		fmt.Println("HTTP ERROR :", err.Error())
	}

}
